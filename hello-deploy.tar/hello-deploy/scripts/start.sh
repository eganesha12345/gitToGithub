#!/bin/bash

/tmp/hello-world-app
