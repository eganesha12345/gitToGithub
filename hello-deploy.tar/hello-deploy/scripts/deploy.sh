#!/bin/bash
aws s3 cp s3://eg-bucket-13041974/main-binary/hello-world-app /tmp/
